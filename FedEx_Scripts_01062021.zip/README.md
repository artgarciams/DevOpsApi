# DevOpsApi
PowerShell to work with Azure DevOps API

This set of PowerShell scripts will allow the creation of : </br>Azure DevOps Projects 
                                                            Teams </br>
                                                            Build </br>
                                                            Environments </br>
                                                            Add members to teams </br>
                                                            
You can also list all the allow and deny permissions for a given Organization and Project </br> 
using Get-SecurityForGivenNamespaces

You can also create , List and delete branches in the Git Repos
